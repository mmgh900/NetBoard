first run a server
and then run clients


/if there was an error,
 please uncomment "addSampleClients()" in Server class, line 51 to reset sthe server.